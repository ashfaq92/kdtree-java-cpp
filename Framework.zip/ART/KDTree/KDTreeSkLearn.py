import numpy as np
from sklearn.neighbors import KDTree

np.random.seed(1)
X = np.random.random((5, 2))  # 5 points in 2 dimensions
# print(X)
tree = KDTree(X)

q = np.random.random((1, 2))
resp = tree.query(q, k=1)  # k=2 nearest neighbors where k1 = identity
print(resp)

(0.417022004702574, 0.7203244934421581),(0.00011437481734488664, 0.30233257263183977),(0.14675589081711304, 0.0923385947687978),(0.1862602113776709, 0.34556072704304774),(0.39676747423066994, 0.538816734003357)