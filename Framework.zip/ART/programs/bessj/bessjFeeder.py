from ctypes import *
import random
import math
import time

from fscs.FSCS import FSCS
from vectorization.FSCS_VECTORIZED import FSCS_SIMD


class BessjFeeder:  # <= note!
    domain = [(2, 300), (-1000, 15000)]  # <= note!
    dllPath = "C:\\Users\Muhammad Ashfaq\\OneDrive\\Programming\\ART\\programs\\bessj\\dpt_bessj.dll"  # <= note!
    lib = cdll.LoadLibrary(dllPath)

    lib.original_fn.argtypes = [c_double, c_double]  # <= note!
    lib.modified_fn.restype = c_double  # <= note!
    lib.modified_fn.argtypes = [c_double, c_double]  # <= note!
    lib.original_fn.restype = c_double  # <= note!

    def __init__(self, sim):
        self.simulations = sim

    def gen_rand_tc(self):
        # print(self.domain)
        return tuple(random.uniform(coord[0], coord[1]) for coord in self.domain)

    def randomTesting(self, seedArg=None):
        random.seed(seedArg)
        fileName = "bessjRT.txt"  # <= note!
        f = open(fileName, "a")
        fMeasure = 0.0
        tcGenTime = 0.0
        execTime = 0.0
        while True:
            start = time.time()
            tc = self.gen_rand_tc()
            tcGenTime = tcGenTime + (time.time() - start)

            fMeasure = fMeasure + 1

            start = time.time()
            # revealFailure = self.lib.Produces_Error(tc[0])      # <= note!
            revealFailure = self.lib.original_fn(tc[0], tc[1]) != self.lib.modified_fn(tc[0], tc[1])  # <= note!
            execTime = execTime + (time.time() - start)

            if revealFailure:
                f.write(str(fMeasure) + "\t" + str(tcGenTime) + "\t" + str(execTime) + "\n")
                f.close()
                return {"fMeasure": fMeasure, "tcGenTime": tcGenTime, "execTime": execTime}

    def fscsTesting(self, seedArg=None):
        fileName = "bessjFSCS.txt"  # <= note!
        f = open(fileName, "a")
        myFscs = FSCS(self.domain, seed=seedArg)
        initial_test_data = self.gen_rand_tc()
        myFscs.selected_set.append(initial_test_data)
        tcGenTime = 0.0
        execTime = 0.0
        while True:
            start = time.time()
            tc = myFscs.select_best_test_case()
            tcGenTime = tcGenTime + (time.time() - start)

            myFscs.selected_set.append(tc)

            start = time.time()
            revealFailure = self.lib.original_fn(tc[0], tc[1]) != self.lib.modified_fn(tc[0], tc[1])  # <= note!
            execTime = execTime + (time.time() - start)
            if revealFailure:
                f.write(str(len(myFscs.selected_set)) + "\t" + str(tcGenTime) + "\t" + str(execTime) + "\n")
                f.close()
                return {"fMeasure": len(myFscs.selected_set), "tcGenTime": tcGenTime, "execTime": execTime}

    def fscsSimdTesting(self, seedArg=None):
        fileName = "bessjFSCS_SIMD.txt"  # <== note!
        f = open(fileName, "a")
        myFscsSimd = FSCS_SIMD(self.domain, seed=seedArg)
        initial_test_data = self.gen_rand_tc()
        myFscsSimd.selected_set.append(initial_test_data)
        tcGenTime = 0.0
        execTime = 0.0
        while True:
            start = time.time()
            tc = myFscsSimd.selectBestTc()
            tcGenTime = tcGenTime + (time.time() - start)

            myFscsSimd.selected_set.append(tc)

            start = time.time()
            revealFailure = self.lib.original_fn(tc[0], tc[1]) != self.lib.modified_fn(tc[0], tc[1])  # <= note!
            execTime = execTime + (time.time() - start)

            if revealFailure:
                f.write(str(len(myFscsSimd.selected_set)) + "\t" + str(tcGenTime) + "\t" + str(execTime) + "\n")
                f.close()
                return {"fMeasure": len(myFscsSimd.selected_set), "tcGenTime": tcGenTime, "execTime": execTime}

    def main(self):
        RT_Fm, RT_tcGenTime, RT_execTime = 0.0, 0.0, 0.0
        FSCS_Fm, FSCS_tcGenTime, FSCS_execTime = 0.0, 0.0, 0.0
        FSCS_SIMD_Fm, FSCS_SIMD_tcGenTime, FSCS_SIMD_execTime = 0.0, 0.0, 0.0

        for i in range(self.simulations):
            # randSeed = random.random()
            # resp = self.randomTesting(seedArg=randSeed)
            # # print("RT", resp)
            # RT_Fm = RT_Fm + resp['fMeasure']
            # RT_tcGenTime = RT_tcGenTime + resp['tcGenTime']
            # RT_execTime = RT_execTime + resp['execTime']

            resp = self.fscsTesting()
            print("FSCS", resp)
            FSCS_Fm = FSCS_Fm + resp['fMeasure']
            FSCS_tcGenTime = FSCS_tcGenTime + resp['tcGenTime']
            FSCS_execTime = FSCS_execTime + resp['execTime']

            # resp = self.fscsSimdTesting(seedArg=randSeed)
            # # print("FSCS_SIMD", resp)
            # FSCS_SIMD_Fm = FSCS_SIMD_Fm + resp['fMeasure']
            # FSCS_SIMD_tcGenTime = FSCS_SIMD_tcGenTime + resp['tcGenTime']
            # FSCS_SIMD_execTime = FSCS_SIMD_execTime + resp['execTime']

        print("F_measure  \t  tcGenTime  \t execTime  \t ftime")
        print("RT:", (RT_Fm / self.simulations), "\t", (RT_tcGenTime / self.simulations), "\t",
              (RT_execTime / self.simulations))
        print("FSCS:", (FSCS_Fm / self.simulations), "\t", (FSCS_tcGenTime / self.simulations), "\t",
              (FSCS_execTime / self.simulations))
        print("FSCS_SIMD:", (FSCS_SIMD_Fm / self.simulations), "\t", (FSCS_SIMD_tcGenTime / self.simulations), "\t",
              (FSCS_SIMD_execTime / self.simulations))


if __name__ == '__main__':
    sim = 3000
    myBessjFeeder = BessjFeeder(sim)
    myBessjFeeder.main()
    # print(myBessjFeeder.lib.original_fn(284.2352388448975, 9617.575791249143))
    # print(myBessjFeeder.lib.modified_fn(284.2352388448975, 9617.575791249143))
