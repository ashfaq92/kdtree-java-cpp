from ctypes import *
import random
import math
import time

from fscs.FSCS import FSCS
from vectorization.FSCS_VECTORIZED import FSCS_SIMD


class CelFeeder:  # <= note!
    domain = [(0.001, 1), (0.001, 300), (0.001, 10000), (0.001, 1000)]  # <= note!
    dllPath = "C:\\Users\Muhammad Ashfaq\\OneDrive\\Programming\\ART\\programs\\cel\\dpt_cel.dll"  # <= note!
    lib = cdll.LoadLibrary(dllPath)

    lib.Produces_Error.argtypes = [c_double, c_double, c_double, c_double]  # <= note!
    lib.cel.argtypes = [c_double, c_double, c_double, c_double]  # <= note!
    lib.celm.argtypes = [c_double, c_double, c_double, c_double]  # <= note!

    lib.Produces_Error.restype = c_bool  # <= note!
    lib.cel.restype = c_double  # <= note!
    lib.celm.restype = c_double  # <= note!

    def __init__(self, sim):
        self.simulations = sim

    def gen_rand_tc(self):
        return tuple(random.uniform(coord[0], coord[1]) for coord in self.domain)

    def randomTesting(self, seedArg=None):
        random.seed(seedArg)
        fileName = "celRT.txt"  # <= note!
        f = open(fileName, "a")
        fMeasure = 0
        tcGenTime = 0
        execTime = 0
        while True:
            start = time.time()
            tc = self.gen_rand_tc()
            tcGenTime = tcGenTime + (time.time() - start)

            fMeasure = fMeasure + 1

            start = time.time()
            revealFailure = self.lib.Produces_Error(tc[0], tc[1], tc[2], tc[3])  # <= note!
            # revealFailure = self.lib.original_fn(tc[0], tc[1]) != self.lib.modified_fn(tc[0], tc[1])  # <= note!
            execTime = execTime + (time.time() - start)

            if revealFailure:
                f.write(str(fMeasure) + "\t" + str(tcGenTime) + "\t" + str(execTime) + "\n")
                f.close()
                return {"fMeasure": fMeasure, "tcGenTime": tcGenTime, "execTime": execTime}

    def fscsTesting(self, seedArg=None):
        fileName = "celFSCS.txt"  # <= note!
        f = open(fileName, "a")
        myFscs = FSCS(self.domain, seed=seedArg)
        initial_test_data = self.gen_rand_tc()
        myFscs.selected_set.append(initial_test_data)
        tcGenTime = 0
        execTime = 0
        while True:
            start = time.time()
            tc = myFscs.select_best_test_case()
            tcGenTime = tcGenTime + (time.time() - start)

            myFscs.selected_set.append(tc)

            start = time.time()
            revealFailure = self.lib.Produces_Error(tc[0], tc[1], tc[2], tc[3])  # <= note!
            execTime = execTime + (time.time() - start)
            if revealFailure:
                f.write(str(len(myFscs.selected_set)) + "\t" + str(tcGenTime) + "\t" + str(execTime) + "\n")
                f.close()
                return {"fMeasure": len(myFscs.selected_set), "tcGenTime": tcGenTime, "execTime": execTime}

    def fscsSimdTesting(self, seedArg=None):
        fileName = "celFSCS_SIMD.txt"  # <== note!
        f = open(fileName, "a")
        myFscsSimd = FSCS_SIMD(self.domain, seed=seedArg)
        initial_test_data = self.gen_rand_tc()
        myFscsSimd.selected_set.append(initial_test_data)
        tcGenTime = 0
        execTime = 0
        while True:
            start = time.time()
            tc = myFscsSimd.selectBestTc()
            tcGenTime = tcGenTime + (time.time() - start)

            myFscsSimd.selected_set.append(tc)

            start = time.time()
            revealFailure = self.lib.Produces_Error(tc[0], tc[1], tc[2], tc[3])  # <= note!
            execTime = execTime + (time.time() - start)

            if revealFailure:
                f.write(str(len(myFscsSimd.selected_set)) + "\t" + str(tcGenTime) + "\t" + str(execTime) + "\n")
                f.close()
                return {"fMeasure": len(myFscsSimd.selected_set), "tcGenTime": tcGenTime, "execTime": execTime}

    def main(self):
        RT_Fm, RT_tcGenTime, RT_execTime = 0, 0, 0
        FSCS_Fm, FSCS_tcGenTime, FSCS_execTime = 0, 0, 0
        FSCS_SIMD_Fm, FSCS_SIMD_tcGenTime, FSCS_SIMD_execTime = 0, 0, 0

        for i in range(self.simulations):
            # randSeed = random.random()
            resp = self.randomTesting()
            # print("RT", resp)
            RT_Fm = RT_Fm + resp['fMeasure']
            RT_tcGenTime = RT_tcGenTime + resp['tcGenTime']
            RT_execTime = RT_execTime + resp['execTime']

            resp = self.fscsTesting()
            # print("FSCS", resp)
            FSCS_Fm = FSCS_Fm + resp['fMeasure']
            FSCS_tcGenTime = FSCS_tcGenTime + resp['tcGenTime']
            FSCS_execTime = FSCS_execTime + resp['execTime']

            resp = self.fscsSimdTesting()
            # print("FSCS_SIMD", resp)
            FSCS_SIMD_Fm = FSCS_SIMD_Fm + resp['fMeasure']
            FSCS_SIMD_tcGenTime = FSCS_SIMD_tcGenTime + resp['tcGenTime']
            FSCS_SIMD_execTime = FSCS_SIMD_execTime + resp['execTime']

        print("F_measure  \t  tcGenTime  \t execTime  \t ftime")
        print("RT:", (RT_Fm / self.simulations), "\t", (RT_tcGenTime / self.simulations), "\t",
              (RT_execTime / self.simulations))
        print("FSCS:", (FSCS_Fm / self.simulations), "\t", (FSCS_tcGenTime / self.simulations), "\t",
              (FSCS_execTime / self.simulations))
        print("FSCS_SIMD:", (FSCS_SIMD_Fm / self.simulations), "\t", (FSCS_SIMD_tcGenTime / self.simulations), "\t",
              (FSCS_SIMD_execTime / self.simulations))


if __name__ == '__main__':
    sims = 3000
    myCelFeeder = CelFeeder(sim=sims)
    myCelFeeder.main()
    # print(myCelFeeder.lib.cel(0.05, 100.10, 150, 200))
    # print(myCelFeeder.lib.cel(0.05, 100.10, 150, 200))
