//to make exe file: gcc testProg.c –o testProg

#include <stdio.h>

int square(int a) {
 return (a * a);
}

