import itertools
import random


class TwelveBeadnD:
    def __init__(self, bd, refined=False):
        self.domain = bd
        self.dimensions = len(self.domain)
        self.globals = []  # replacement of global_x, global_y, global_z ... etc.
        self.pools = []
        self.global_pairs = []
        self.refined = refined
        for d in self.domain:
            if self.refined:
                self.globals.append(set())
            elif not self.refined:
                self.globals.append({d[0], d[1]})
            self.pools.append(set())
            self.global_pairs.append(list())
        for i in range(self.dimensions):
            self.global_pairs[i] = self.splitter(self.domain[i][0], self.domain[i][1], self.pools[i], self.globals[i])
        self.iter = 0
        self.unique_points = set()
        self.selected_set = []

    def splitter(self, x1, x2, pool, global_coord=None):
        mid = (x1 + x2) / 2
        pool.add(mid)
        if global_coord is not None:
            global_coord.add(mid)
        left_half = (x1, mid)
        right_half = (mid, x2)
        return left_half, right_half

    def wrapper(self):
        self.unique_points.clear()
        if self.iter == 0:
            if not self.refined:
                for element in itertools.product(*self.domain):
                    self.unique_points.add(element)
            for element in itertools.product(*self.pools):
                self.unique_points.add(element)
            for i in range(self.dimensions):
                temp_pools = list(self.pools)  # make new list of pools so that original pools stays untouched
                temp_pools[i] = self.globals[i]  # <= main thing
                for element in itertools.product(*temp_pools):
                    self.unique_points.add(element)
        else:
            temps = []
            for i in range(self.dimensions):
                temps.append(list())
                self.pools[i].clear()
            for c in range(self.dimensions):
                for x in self.global_pairs[c]:
                    temps[c].extend(self.splitter(x[0], x[1], self.pools[c], self.globals[c]))
            for c in range(self.dimensions):
                self.global_pairs[c] = temps[c]

            if self.dimensions == 1:
                for x in self.pools[0]:
                    self.unique_points.add((x,))
            else:
                for element in itertools.product(*self.pools):
                    self.unique_points.add(element)
                for i in range(self.dimensions):
                    temp_pools = list(self.pools)
                    temp_pools[i] = self.globals[i]
                    for element in itertools.product(*temp_pools):
                        self.unique_points.add(element)
        self.iter = self.iter + 1
        return self.unique_points

    def testEffectiveness(self, failure_region):
        while True:
            pool = list(self.wrapper())
            pool.extend(self.wrapper())
            random.shuffle(pool)
            for tc in pool:
                self.selected_set.append(tc)
                if failure_region.findTarget(tc):
                    return len(self.selected_set)

    @classmethod
    def generate_points(cls, bd, n, refined=False):
        tempObj = TwelveBeadnD(bd, refined=refined)
        test_set = []
        while True:
            pool = list(tempObj.wrapper())
            random.shuffle(pool)
            for tc in pool:
                test_set.append(tc)
                if len(test_set) == n:
                    return test_set


if __name__ == '__main__':
    domain = [(-5000, 5000), (-5000, 5000)]
    tbnd = TwelveBeadnD(domain, refined=False)
    tbndf = TwelveBeadnD(domain, refined=True)
