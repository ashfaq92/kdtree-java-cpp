import random
import time
import functions
import sys

simulations = 3000
input_min = 0.0
input_max = 1.0
avg_f_measure = 0
total_f_measure = 0
failure_rate = [0.1]
dimensions = 2

start_time = time.time()
for x in range(simulations):
    i = 0
    failure_point = functions.generate_failure_point(input_min, input_max, failure_rate[0], dimensions)
    print(failure_point)
    while True:
        test_case = tuple(random.uniform(input_min, input_max) for d in range(dimensions))
        # print(test_case)
        # sys.exit()
        reveal_failure = functions.test_program(failure_point, test_case)
        i = i + 1
        if reveal_failure is True:
            f_measure = i
            total_f_measure = total_f_measure + f_measure
            break

# time_taken = time.time() - start_time
# print("--- %s seconds ---" % (time.time() - start_time))
avg_f_measure = total_f_measure / simulations
print("avg_f_measure", format(avg_f_measure))

