import math
import random
import sys


def test_triangle(tc, triangle):
    failure_found = False
    PA = (tc[0] - triangle[0][0], tc[1] - triangle[0][1])
    PB = (tc[0] - triangle[1][0], tc[1] - triangle[1][1])
    PC = (tc[0] - triangle[2][0], tc[1] - triangle[2][1])
    a = PA[0] * PB[1] - PA[1] * PB[0]
    b = PB[0] * PC[1] - PB[1] * PC[0]
    c = PC[0] * PA[1] - PC[1] * PA[0]
    if (a <= 0 and b <= 0 and c <= 0) or (a > 0 and b > 0 and c > 0):
        failure_found = True
    return failure_found


def euclidean_distance(x, y):
    """ return euclidean distance between two lists """
    return math.sqrt(sum(pow(a - b, 2) for a, b in zip(x, y)))


def calculate_triangle_area(a):
    b = a
    c = math.sqrt(a ** 2 + b ** 2)
    s = (a + b + c) / 2
    area = math.sqrt(s * (s - a) * (s - b) * (s - c))
    return area


def create_strip(f_rate):
    mirrored_pool = ["BOTTOM_LEFT", "BOTTOM_RIGHT", "TOP_LEFT", "TOP_RIGHT"]
    mirrored_pool = ["BOTTOM_LEFT"]
    mirror = random.choice(mirrored_pool)
    triangle1_point = random.uniform(0, 1 - f_rate)
    triangle1_point = 0.5
    area1 = calculate_triangle_area(triangle1_point)
    increment = f_rate / 10000
    triangle2_point = triangle1_point
    while True:
        area2 = calculate_triangle_area(triangle2_point)
        strip_area = area2 - area1
        if strip_area >= f_rate:
            break
        else:
            triangle2_point = triangle2_point + increment
    pts = None
    if mirror == "BOTTOM_LEFT":
        pts = [(0, triangle1_point), (triangle1_point, 0), (0, triangle2_point), (triangle2_point, 0), mirror]
    elif mirror == "TOP_RIGHT":
        pts = [(1, 1 - triangle1_point), (1 - triangle1_point, 1), (1, 1 - triangle2_point), (1 - triangle2_point, 1),
               mirror]
    elif mirror == "BOTTOM_RIGHT":
        pts = [(1 - triangle1_point, 0), (1, triangle1_point), (1 - triangle2_point, 0), (1, triangle2_point), mirror]
    elif mirror == "TOP_LEFT":
        pts = [(0, 1 - triangle1_point), (triangle1_point, 1), (0, 1 - triangle2_point), (triangle2_point, 1), mirror]
    return pts


simulations = 3000
totalFMeasure = 0
for i in range(1, simulations + 1):
    resp = create_strip(0.1)
    # diagonal1 = euclidean_distance(resp[0], resp[3])
    # diagonal2 = euclidean_distance(resp[1], resp[2])
    # if diagonal1 != diagonal2:
    #     print("diagonals not equal")
    #     print(resp)
    #     print(diagonal1)
    #     print(diagonal2)
    #     sys.exit()

    triangle1 = [resp[0], resp[1], resp[2]]
    triangle2 = [resp[1], resp[2], resp[3]]
    print(resp)
    sys.exit()
    random.seed()
    f_measure = 0
    reveal_failure = False
    while reveal_failure is False:
        f_measure = f_measure + 1
        test_case = (random.random(), random.random())
        inTriangle1 = test_triangle(test_case, triangle1)
        inTriangle2 = test_triangle(test_case, triangle2)
        if (inTriangle1 is True) or (inTriangle2 is True):
            break
    totalFMeasure = totalFMeasure + f_measure
    print(i, "f_measure:", f_measure, "mean", totalFMeasure / i)
avg_fM = totalFMeasure / simulations
print("AVG f-measure:", avg_fM)
