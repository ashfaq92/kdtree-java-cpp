import math
import random


def calculate_triangle_area(a):
    b = a
    c = math.sqrt(a ** 2 + b ** 2)
    s = (a + b + c) / 2
    area = math.sqrt(s * (s - a) * (s - b) * (s - c))
    return area


def test_point(point, strip_pts):
    inside = False
    a = point[0] + point[1]
    if strip_pts[0] < a < strip_pts[1]:
        inside = True
    return inside


def create_strip(f_rate):
    triangle1_point = random.uniform(0, 1 - f_rate)
    area1 = calculate_triangle_area(triangle1_point)
    increment = f_rate / 100
    strip_area = 0
    triangle2_point = triangle1_point
    while strip_area < f_rate:
        triangle2_point = triangle2_point + increment
        area2 = calculate_triangle_area(triangle2_point)
        strip_area = area2 - area1
    return [triangle1_point, triangle2_point, strip_area]


simulations = 5000
totalFMeasure = 0
for i in range(1, simulations+1):
    resp = create_strip(0.1)
    f_measure = 0
    reveal_failure = False
    while reveal_failure is False:
        f_measure = f_measure + 1
        test_case = (random.random(), random.random())
        reveal_failure = test_point(test_case, resp)
    totalFMeasure = totalFMeasure + f_measure
    print(i, "f_measure:", f_measure, "mean", totalFMeasure / i)
avg_fM = totalFMeasure / simulations
print("AVG f-measure:", avg_fM)
