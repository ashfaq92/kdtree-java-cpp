import random
import winsound
import time
import sys
import math

simulations = 3000
failure_rate = 0.01
dimension = 2
random.seed()
input_min = 0.0
input_max = 1.0
avg_f_measure = 0
total_f_measure = 0
f_ratio = 0
total_number_of_candidates = 10

failure_region_area = input_max * failure_rate
failure_region_length = failure_region_area ** (1 / dimension)
upper_bound = input_max - failure_region_length


def test_triangle(tc, triangle):
    failure_found = False
    PA = (tc[0] - triangle[0][0], tc[1] - triangle[0][1])
    PB = (tc[0] - triangle[1][0], tc[1] - triangle[1][1])
    PC = (tc[0] - triangle[2][0], tc[1] - triangle[2][1])
    a = PA[0] * PB[1] - PA[1] * PB[0]
    b = PB[0] * PC[1] - PB[1] * PC[0]
    c = PC[0] * PA[1] - PC[1] * PA[0]
    if (a <= 0 and b <= 0 and c <= 0) or (a > 0 and b > 0 and c > 0):
        failure_found = True
    return failure_found


def euclidean_distance(x, y):
    """ return euclidean distance between two lists """
    return math.sqrt(sum(pow(a - b, 2) for a, b in zip(x, y)))


def calculate_triangle_area(a):
    b = a
    c = math.sqrt(a ** 2 + b ** 2)
    s = (a + b + c) / 2
    area = math.sqrt(s * (s - a) * (s - b) * (s - c))
    return area


def create_strip(f_rate):
    triangle1_point = random.uniform(0, 1 - f_rate)
    area1 = calculate_triangle_area(triangle1_point)
    increment = f_rate / 10000
    strip_area = 0
    triangle2_point = triangle1_point
    while strip_area < f_rate:
        triangle2_point = triangle2_point + increment
        area2 = calculate_triangle_area(triangle2_point)
        strip_area = area2 - area1
    return [triangle1_point, triangle2_point, strip_area]


def select_the_best_test_data(selectedSet, totalNumberOfCandidates, dimensionsArg):
    best_distance = -1.0
    best_data = None
    # Generate unique random candidates
    for i in range(totalNumberOfCandidates):
        candidate = tuple(random.random() for j in range(dimensionsArg))
        min_candidate_distance = 9223372036854775807
        for x in range(len(selectedSet)):
            # distance = math.sqrt(sum(pow(a - b, 2) for a, b in zip(selected_set[x], candidate)))
            distance = (sum(pow(a - b, 2) for a, b in zip(selected_set[x], candidate))) ** (0.5)
            # find minimum distance MIN
            if distance < min_candidate_distance:
                min_candidate_distance = distance
        # find maximum distance from all minimum distances MAX
        if best_distance < min_candidate_distance:
            best_data = candidate
            best_distance = min_candidate_distance
    return best_data


total_time = 0.0
for x in range(1, simulations + 1):
    start_time = time.time()
    # Generate Failure point
    resp = create_strip(failure_rate)
    p1 = (0, resp[0])
    p2 = (resp[0], 0)
    p3 = (0, resp[1])
    p4 = (resp[1], 0)
    # print(p1, ",", p2, ",", p3, ",", p4)
    # sys.exit()
    diagonal1 = euclidean_distance(p4, p1)
    diagonal2 = euclidean_distance(p3, p2)
    if diagonal1 != diagonal2:
        print("there is an error in program")
        sys.exit()
    triangle1 = [p1, p2, p3]
    triangle2 = [p2, p3, p4]
    initial_test_data = tuple(random.random() for d in range(dimension))
    selected_set = [initial_test_data]
    counter = 1
    # use initial data to test the program
    # reveal_failure = test_triangle(initial_test_data, resp)
    reveal_failure = False
    while reveal_failure is False:
        # t = 0
        # while t < 2000:
        test_data = select_the_best_test_data(selected_set, total_number_of_candidates, dimension)
        # use test_data to test the program
        test_case = (random.random(), random.random())
        inTriangle1 = test_triangle(test_data, triangle1)
        inTriangle2 = test_triangle(test_data, triangle2)
        if (inTriangle1 is True) or (inTriangle2 is True):
            break
        selected_set.append(test_data)
        counter = counter + 1
        # t = t + 1
        # print(t)
    # print(counter)
    time_taken = time.time() - start_time
    total_time = total_time + time_taken
    total_f_measure = total_f_measure + counter
    print(x, 'time', time.time() - start_time, 'f-measure', counter, 'mean ', total_f_measure / x)

avg_f_measure = total_f_measure / simulations
f_ratio = avg_f_measure * failure_rate
result = {'simulations': simulations, 'dimension': dimension, 'failure_rate': failure_rate,
          'avg_f_measure': avg_f_measure, 'f_ratio': f_ratio, 'avg_time_taken': total_time / simulations}
print("\n")
print(result)

winsound.MessageBeep(winsound.MB_OK)


def visulalize(X):
    import matplotlib.pyplot as plt
    print('printing scatter plot...')
    x = []
    y = []
    for i in X:
        x.append(i[0])
        y.append(i[1])

    plt.scatter(x, y, edgecolors='w')

    plt.show()
    print('printed successfully!')
