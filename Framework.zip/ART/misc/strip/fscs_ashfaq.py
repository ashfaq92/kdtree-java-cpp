import random
import winsound
import time
import sys
import math

simulations = 1500
failure_rate = 0.01
dimension = 2
random.seed()
input_min = 0.0
input_max = 1.0
avg_f_measure = 0
total_f_measure = 0
f_ratio = 0
total_number_of_candidates = 10

failure_region_area = input_max * failure_rate
failure_region_length = failure_region_area ** (1 / dimension)
upper_bound = input_max - failure_region_length


def test_triangle(tc, triangle):
    failure_found = False
    PA = (tc[0] - triangle[0][0], tc[1] - triangle[0][1])
    PB = (tc[0] - triangle[1][0], tc[1] - triangle[1][1])
    PC = (tc[0] - triangle[2][0], tc[1] - triangle[2][1])
    a = PA[0] * PB[1] - PA[1] * PB[0]
    b = PB[0] * PC[1] - PB[1] * PC[0]
    c = PC[0] * PA[1] - PC[1] * PA[0]
    if (a <= 0 and b <= 0 and c <= 0) or (a > 0 and b > 0 and c > 0):
        failure_found = True
    return failure_found


def euclidean_distance(x, y):
    """ return euclidean distance between two lists """
    return math.sqrt(sum(pow(a - b, 2) for a, b in zip(x, y)))


def calculate_triangle_area(a):
    b = a
    c = math.sqrt(a ** 2 + b ** 2)
    s = (a + b + c) / 2
    area = math.sqrt(s * (s - a) * (s - b) * (s - c))
    return area


def create_strip(f_rate):
    mirrored_pool = ["BOTTOM_LEFT", "BOTTOM_RIGHT", "TOP_LEFT", "TOP_RIGHT"]
    mirror = random.choice(mirrored_pool)
    # triangle1_point = random.uniform(0, 1 - f_rate)
    triangle1_point = 0.5
    area1 = calculate_triangle_area(triangle1_point)
    increment = f_rate / 10000
    triangle2_point = triangle1_point
    while True:
        area2 = calculate_triangle_area(triangle2_point)
        strip_area = area2 - area1
        if strip_area >= f_rate:
            break
        else:
            triangle2_point = triangle2_point + increment
    pts = None
    if mirror == "BOTTOM_LEFT":
        pts = [(0, triangle1_point), (triangle1_point, 0), (0, triangle2_point), (triangle2_point, 0), mirror]
    elif mirror == "TOP_RIGHT":
        pts = [(1, 1 - triangle1_point), (1 - triangle1_point, 1), (1, 1 - triangle2_point), (1 - triangle2_point, 1),
               mirror]
    elif mirror == "BOTTOM_RIGHT":
        pts = [(1 - triangle1_point, 0), (1, triangle1_point), (1 - triangle2_point, 0), (1, triangle2_point), mirror]
    elif mirror == "TOP_LEFT":
        pts = [(0, 1 - triangle1_point), (triangle1_point, 1), (0, 1 - triangle2_point), (triangle2_point, 1), mirror]
    return pts


def select_the_best_test_data(selectedSet, totalNumberOfCandidates, dimensionsArg):
    best_distance = -1.0
    best_data = None
    # Generate unique random candidates
    for i in range(totalNumberOfCandidates):
        candidate = tuple(random.random() for j in range(dimensionsArg))
        min_candidate_distance = 9223372036854775807
        for x in range(len(selectedSet)):
            # distance = math.sqrt(sum(pow(a - b, 2) for a, b in zip(selected_set[x], candidate)))
            distance = (sum(pow(a - b, 2) for a, b in zip(selected_set[x], candidate))) ** 0.5
            # find minimum distance MIN
            if distance < min_candidate_distance:
                min_candidate_distance = distance
        # find maximum distance from all minimum distances MAX
        if best_distance < min_candidate_distance:
            best_data = candidate
            best_distance = min_candidate_distance
    return best_data


total_time = 0.0
for x in range(1, simulations + 1):
    resp = create_strip(failure_rate)
    # print(resp)
    start_time = time.time()
    # Generate Failure point
    random.seed()
    initial_test_data = tuple(random.random() for d in range(dimension))
    selected_set = [initial_test_data]
    triangle1 = [resp[0], resp[1], resp[2]]
    triangle2 = [resp[1], resp[2], resp[3]]
    f_measure = 0
    reveal_failure = test_triangle(initial_test_data, resp)
    while reveal_failure is False:
        f_measure = f_measure + 1
        test_data = select_the_best_test_data(selected_set, total_number_of_candidates, dimension)
        inTriangle1 = test_triangle(test_data, triangle1)
        inTriangle2 = test_triangle(test_data, triangle2)
        if (inTriangle1 is True) or (inTriangle2 is True):
            break
        selected_set.append(test_data)
    total_f_measure = total_f_measure + f_measure
    print(x, 'f-measure', f_measure, 'mean ', total_f_measure / x)

avg_f_measure = total_f_measure / simulations
f_ratio = avg_f_measure * failure_rate
result = {'simulations': simulations, 'dimension': dimension, 'failure_rate': failure_rate,
          'avg_f_measure': avg_f_measure, 'f_ratio': f_ratio, 'avg_time_taken': total_time / simulations}
print("\n")
print(result)

winsound.MessageBeep(winsound.MB_OK)


def visulalize(X):
    import matplotlib.pyplot as plt
    print('printing scatter plot...')
    x = []
    y = []
    for i in X:
        x.append(i[0])
        y.append(i[1])

    plt.scatter(x, y, edgecolors='w')

    plt.show()
    print('printed successfully!')
