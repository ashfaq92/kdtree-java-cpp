import sys
import random


class FSCS:
    def __init__(self, dom, candidates=10):
        self.domain = dom
        self.dimensions = len(self.domain)
        self.candidate_num = candidates
        self.selected_set = []

    def gen_rand_tc(self):
        test_case = []
        for coord in self.domain:
            test_case.append(random.uniform(coord[0], coord[1]))
        return tuple(test_case)

    def select_best_test_case(self):
        best_distance = -1.0
        best_data = None
        # Generate unique random candidates
        for i in range(self.candidate_num):
            candidate = self.gen_rand_tc()
            min_candidate_distance = sys.maxsize
            for x in range(len(self.selected_set)):
                distance = (sum(pow(a - b, 2) for a, b in zip(self.selected_set[x], candidate))) ** 0.5
                # find minimum distance MIN
                if distance < min_candidate_distance:
                    min_candidate_distance = distance
            # find maximum distance from all minimum distances MAX
            if best_distance < min_candidate_distance:
                best_data = candidate
                best_distance = min_candidate_distance
        return best_data

    def testEffectiveness(self, failure_region):
        self.selected_set.clear()
        initial_test_data = tuple(random.random() for d in range(self.dimensions))
        self.selected_set.append(initial_test_data)
        while True:
            tc = self.select_best_test_case()
            self.selected_set.append(tc)
            if failure_region.findTarget(tc):
                return len(self.selected_set)

    def generate_points(self, n):
        self.selected_set.clear()
        initial_test_data = self.gen_rand_tc()
        self.selected_set.append(initial_test_data)
        while True:
            test_case = self.select_best_test_case()
            self.selected_set.append(test_case)
            if len(self.selected_set) == n:
                return self.selected_set


bd = [(-5000, 5000), (-5000, 5000)]
myFSCS = FSCS(bd)
#
print(myFSCS.generate_points(100))
