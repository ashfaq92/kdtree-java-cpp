import time
import winsound
import random

import numpy as np

dim = 2

executed_set = []

iterations = 5000000


def nn(X, candidate):
    nearest_point = None
    min_dist = 9223372036854775807

    for x in X:
        distance = (sum(pow(a - b, 2) for a, b in zip(x, candidate))) ** 0.5
        if distance < min_dist:
            min_dist = distance
            nearest_point = x
    return nearest_point


for i in range(iterations):
    point = tuple(random.random() for d in range(dim))
    executed_set.append(point)

q = tuple(random.random() for d in range(dim))

start_time = time.time()
res = nn(executed_set, q)
time_taken = time.time() - start_time

# print("set:\t", executed_set)
print("query_point:\t", q)
print("NN:\t\t", res)
print("Time:\t\t", time_taken)

import matplotlib.pyplot as plt

print('printing scatter plot...')
x = []
y = []
for i in executed_set:
    x.append(i[0])
    y.append(i[1])

plt.scatter(x, y, edgecolors='w')
plt.scatter(q[0],q[1], edgecolors='r')
plt.scatter(res[0],res[1], edgecolors='g')
