import time
import winsound
import random

import numpy as np

dim = 2

executed_set = [tuple(random.random() for d in range(dim))]

iterations = 10000


def nn(X, candidate):
    nearest_point = None
    min_dist = 9223372036854775807

    for x in X:
        distance = (sum(pow(a - b, 2) for a, b in zip(x, candidate))) ** 0.5
        if distance < min_dist:
            min_dist = distance
            nearest_point = x

    return {'point': nearest_point, 'distance': min_dist}


start_time = time.time()
for i in range(iterations):
    q = tuple(random.random() for d in range(dim))
    start_time1 = time.time()
    res = nn(executed_set, q)
    time_taken1 = time.time() - start_time1
    print('time taken', format(time_taken1 * 1000), end='\t')
    print(i, res, len(executed_set))
    executed_set.append(q)

time_taken = time.time() - start_time
print(time_taken)
winsound.MessageBeep(winsound.MB_OK)
