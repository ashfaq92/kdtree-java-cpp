import random
import matplotlib.pyplot as plt

simulation = 1
avg_f_measure = 0
total_f_measure = 0
failure_rate = 0.001
dimensions = 1
input_min = 0
input_max = 1
failure_region_area = input_max * failure_rate
failure_region_length = failure_region_area ** (1 / dimensions)
upper_bound = input_max - failure_region_length
etc = []  # Executed test cases


def test_program(fp, test_case, l):
    c = 0
    for i in range(len(fp)):
        if fp[i] < test_case[i] < fp[i] + l:
            c = c + 1
            continue
    if c == len(fp):
        return True

    # if fp[0] < test_case[0] < fp[0] + l:
    #     if fp[1] < test_case[1] < fp[1] + l:
    #         if fp[2] < test_case[2] < fp[2] + l:
    #             # failure revealed True
    #             return True


for x in range(simulation):
    # Generate First point of failure region
    counter = 1
    failure_point = tuple(random.uniform(input_min, upper_bound) for i in range(dimensions))
    test_data = tuple(random.uniform(input_min, input_max) for i in range(dimensions))
    failure_revealed = test_program(failure_point, test_data, failure_region_length)
    etc.append(test_data)
    # while failure_revealed is not True:
    a = 1
    while a < 500:
        test_data = tuple(random.uniform(input_min, input_max) for i in range(dimensions))
        failure_revealed = test_program(failure_point, test_data, failure_region_length)
        etc.append(test_data)
        counter = counter + 1
        a = a + 1

    print(str(x) + " f-measure", format(counter))
    total_f_measure = total_f_measure + counter

avg_f_measure = total_f_measure / simulation
print("avg. f-measure", format(avg_f_measure))


etc_arr = [i[0] for i in etc]
# plt.scatter(x, y, s=50, alpha=0.6, edgecolors='w')
# plt.plot(etc_arr)
# plt.plot(y)
plt.hist(etc_arr)
# plt.hist(y, 50)
