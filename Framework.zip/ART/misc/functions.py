import random
import operator
import itertools

from math import sqrt


def euclidean_distance(x, y):
    """ return euclidean distance between two lists """
    return sqrt(sum(pow(a - b, 2) for a, b in zip(x, y)))


def euclidean_squared_distance(x, y):
    """ return squared euclidean distance between two lists """
    return sum(pow(a - b, 2) for a, b in zip(x, y))


def manhattan_distance(x, y):
    """ return manhattan distance between two lists """
    return sum(abs(a - b) for a, b in zip(x, y))


def generate_failure_point(input_min, input_max, failure_rate, dimensions):
    failure_region_area = input_max * failure_rate
    global failure_region_length
    failure_region_length = failure_region_area ** (1 / dimensions)
    upper_bound = input_max - failure_region_length
    failure_point = tuple(random.uniform(input_min, upper_bound) for d in range(dimensions))
    return failure_point


def generate_coordinates(failure_region_length, failure_point):
    opt = [failure_region_length]
    opt.extend([0] * (len(failure_point) - 1))
    cartesian = list(itertools.product(opt, repeat=len(failure_point)))
    # remove duplicates
    cartesian = list(dict.fromkeys(cartesian))
    coordinates = []
    for i in cartesian:
        coordinates.append(tuple(map(operator.add, i, failure_point)))
    return coordinates


def test_program(failure_point, test_case):
    reveal_failure = None
    if len(failure_point) != len(test_case):
        raise ValueError('dimensions of test case and failure region do not match')
    for i in range(len(failure_point)):
        if failure_point[i] <= test_case[i] <= failure_point[i] + failure_region_length:
            reveal_failure = True
        else:
            reveal_failure = False
    return reveal_failure
