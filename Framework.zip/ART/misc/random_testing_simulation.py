import random
import time

# lets say failure region is when input < 5
# no. of inputs = 100
# no. of failure causing inputs = 5
# failure rate = 5/100 = 0.05
# Expected F-measure = 20
# simulations runs = 500000
# calculating actual f-measure:
avg_f_measure = 0
total_f_measure = 0
simulations = 5000

total_time = 0
start_time = time.time()
for x in range(simulations):
    failure_region = [random.randint(0,99)]
    f_measure = 0
    reveal_failure = False
    while reveal_failure is False:
        tc = random.randint(0, 99)
        f_measure = f_measure + 1
        if tc in failure_region:
            reveal_failure = True
            total_f_measure = total_f_measure + f_measure

time_taken = time.time() - start_time
print("--- %s cumulative time ---" % (time.time() - start_time))
avg_f_measure = total_f_measure / simulations
print("avg_f_measure", format(avg_f_measure))

