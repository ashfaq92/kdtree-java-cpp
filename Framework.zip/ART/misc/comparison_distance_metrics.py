import random
from neighbour import brute_force
from neighbour.fast_nn import fast_nearest_neighbour
min = -5000
max = 5000
dimensions = 2
points = 3000
while True:
    X = []
    for i in range(points):
        X.append(tuple(random.randint(min, max) for x in range(dimensions)))
    # query point y
    y = tuple(random.randint(min, max) for x in range(dimensions))

    euclidean_brute_force = brute_force.euclidean_brute_force(X, y)
    manhattan_brute_force = brute_force.manhattan_brute_force(X, y)

    if euclidean_brute_force['nearest_neighbour'] == manhattan_brute_force['nearest_neighbour']:
        print('same nearest neighbours -_-')
        dimensions = dimensions + 1
    else:
        print('different nearest neighbours')
        print('Dimension', format(dimensions))
        break
