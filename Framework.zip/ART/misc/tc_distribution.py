import matplotlib.pyplot as plt
import random
import time

import fscs_old
import functions

failure_rate = 0.005
dimension = 2
input_min = 0.0
input_max = 1.0
f_ratio = 0
total_number_of_candidates = 10
results = []

start_time = time.time()
failure_point = functions.generate_failure_point(input_min, input_max, failure_rate, dimension)
initial_test_data = tuple(random.uniform(input_min, input_max) for d in range(dimension))
selected_set = [initial_test_data]
counter = 1
# use initial data to test the program
reveal_failure = functions.test_program(failure_point, initial_test_data)

while counter < 500:
    candidate_set = []
    test_data = fscs_old.select_the_best_test_data(selected_set, candidate_set,
                                                   total_number_of_candidates,
                                                   dimension, input_min, input_max)
    # use test_data to test the program
    reveal_failure = functions.test_program(failure_point, test_data)
    selected_set.append(test_data)
    counter = counter + 1
    plt.scatter(test_data[0], test_data[1])

# print(counter)

result = {'dimension': dimension,
          'failure_rate': failure_rate,
          'cumulative_time': time.time() - start_time}
# print(result)
results.append(result)
print(selected_set)


plt.xlabel('x')
plt.ylabel('y')
plt.show()
