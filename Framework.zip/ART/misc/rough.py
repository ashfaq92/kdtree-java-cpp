iteration = 3
progress_width = 50
chunk = iteration / progress_width
i = 0
while i < iteration:
    print('=', end="")
    i = i + chunk
