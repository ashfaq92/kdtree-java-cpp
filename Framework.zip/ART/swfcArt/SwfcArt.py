import hnswlib
import numpy as np
import math


class SwfcArt:
    def __init__(self, domain, candidates=10, ef=2, seed=None):
        np.random.seed(seed)
        self.domain = domain
        self.d = len(self.domain)
        self.candNum = candidates
        self.hnswIndex = hnswlib.Index(space='l2', dim=self.d)
        self.graphSize = 10000
        self.efConst = 3 * math.ceil(math.log10(self.graphSize))
        self.M = self.d * 3
        self.hnswIndex.init_index(self.graphSize, self.efConst, self.M)
        self.hnswIndex.set_ef(ef)
        self.E = []  # executed set

    def selectBestTc(self):
        # C = np.array([self.gen_rand_tc() for _ in range(self.candidate_num)]).astype('float32')
        # C = np.random.uniform(*np.transpose(self.domain)).astype('float32')
        C = np.random.uniform(*np.transpose(self.domain), (self.candNum, self.d)).astype(
            'float32')
        I, D = self.hnswIndex.knn_query(C, 1)  # I=labels; D=distances
        best_distance = np.max(D)
        cIndex = np.where(D == best_distance)
        # print(cIndex)
        return C[cIndex[0][0]]

    def testEffectiveness(self, failure_region):
        # failure region is an object of faultZones classes
        initialTc = np.random.uniform(*np.transpose(self.domain), (1, self.d)).astype('float32')
        self.hnswIndex.add_items(initialTc)
        self.E.append(initialTc[0])
        while True:
            if self.hnswIndex.get_current_count() >= self.hnswIndex.get_max_elements():
                self.graphSize = self.graphSize * 2
                self.efConst = 3 * math.ceil(math.log10(self.graphSize))
                self.hnswIndex = hnswlib.Index(space='l2', dim=self.d)
                self.hnswIndex.init_index(self.graphSize, self.efConst, self.M)
                self.hnswIndex.add_items(self.E)
            tc = self.selectBestTc().reshape(1, self.d)
            self.hnswIndex.add_items(tc)
            self.E.append(tc[0])
            if failure_region.findTarget(tc[0]):
                return self.hnswIndex.get_current_count()

    def generatePoints(self, n, debug=False):
        initialTc = np.random.uniform(*np.transpose(self.domain), (1, self.d)).astype('float32')
        self.hnswIndex.add_items(initialTc)
        self.E.append(initialTc[0])
        while True:
            if self.hnswIndex.get_current_count() >= self.hnswIndex.get_max_elements():
                self.graphSize = self.graphSize * 2
                self.efConst = 3 * math.ceil(math.log10(self.graphSize))
                self.hnswIndex = hnswlib.Index(space='l2', dim=self.d)
                self.hnswIndex.init_index(self.graphSize, self.efConst, self.M)
                self.hnswIndex.add_items(self.E)
            tc = self.selectBestTc().reshape(1, self.d)
            if debug:   print(tuple(tc[0]), end=",")
            self.hnswIndex.add_items(tc)
            self.E.append(tc[0])
            if self.hnswIndex.get_current_count() >= n:
                break


if __name__ == '__main__':
    bd = [(-5000, 5000), (-5000, 5000)]
    tcNum = 1000
    randSeed = 12345
    mySwfcArt = SwfcArt(bd, randSeed)
    mySwfcArt.generatePoints(tcNum, debug=True)
    print()
    print(mySwfcArt.hnswIndex.get_current_count())
    print(len(mySwfcArt.E))


