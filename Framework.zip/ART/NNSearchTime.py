from fscsSimd.fscsSimd import FscsSimd  # Original Software Testing Algorithm
from fscsFaiss.fscsFaiss import FscsFaiss  # Using faiss Original Software Testing Algorithm
from swfcArt.SwfcArt import SwfcArt  # Using hnsw Original Software Testing Algorithm
# ----------------------------------#      # Here will come the using KD-Tree in Original Software Testing Algorithm

import time
import matplotlib.pyplot as plt


class TestEfficiency:
    def __init__(self, sim):
        self.simulations = sim

    def main(self):
        dataSetSizes = [500, 5000, 15000, 20000]
        inputDomains = []
        bd2 = [(-5000, 5000), (-5000, 5000)]  # 2-d input domain
        bd5 = [(-5000, 5000), (-5000, 5000), (-5000, 5000), (-5000, 5000), (-5000, 5000)]  # 5-d input domain
        bd10 = [(-5000, 5000), (-5000, 5000), (-5000, 5000), (-5000, 5000), (-5000, 5000), (-5000, 5000), (-5000, 5000),
                (-5000, 5000), (-5000, 5000), (-5000, 5000)]  # 10-d input domain
        bd15 = [(-5000, 5000), (-5000, 5000), (-5000, 5000), (-5000, 5000), (-5000, 5000), (-5000, 5000), (-5000, 5000),
                (-5000, 5000), (-5000, 5000), (-5000, 5000), (-5000, 5000), (-5000, 5000), (-5000, 5000), (-5000, 5000),
                (-5000, 5000)]  # 15-d input domain
        inputDomains.append(bd2)
        inputDomains.append(bd5)
        inputDomains.append(bd10)
        inputDomains.append(bd15)

        for d in inputDomains:
            origTimes = []
            hnswTimes = []
            faissTimes = []
            for n in dataSetSizes:
                print('d: ', len(d), 'tcNum', n)
                t1 = self.testOriginalAlg(d, n)
                origTimes.append(t1)
                print(t1, end="\t")
                t2 = self.testUsingHnsw(d, n)
                hnswTimes.append(t2)
                print(t2, end="\t")
                t3 = self.testUsingFaiss(d, n)
                faissTimes.append(t3)
                print(t3, end="\t")
                print("")
            # plt.plot(dataSetSizes, origTimes, label='Inline label')
            # plt.plot(dataSetSizes, hnswTimes)
            # plt.plot(dataSetSizes, faissTimes)
            self.showPlot(d, dataSetSizes, origTimes, hnswTimes, faissTimes)

    def testOriginalAlg(self, bd, n):
        totalTime = 0
        for i in range(self.simulations):
            startTime = time.time()
            myFscsSimd = FscsSimd(bd)
            myFscsSimd.generatePoints(n)
            timeTaken = time.time() - startTime
            totalTime = totalTime + timeTaken
        return totalTime / self.simulations

    def testUsingHnsw(self, bd, n):
        totalTime = 0
        for i in range(self.simulations):
            startTime = time.time()
            mySwfcArt = SwfcArt(bd)
            mySwfcArt.generatePoints(n)
            timeTaken = time.time() - startTime
            totalTime = totalTime + timeTaken
        return totalTime / self.simulations

    def testUsingFaiss(self, bd, n):
        totalTime = 0
        for i in range(self.simulations):
            startTime = time.time()
            myFscsFaiss = FscsFaiss(bd)
            myFscsFaiss.generatePoints(n)
            timeTaken = time.time() - startTime
            totalTime = totalTime + timeTaken
        return totalTime / self.simulations

    def showPlot(self, d, dataSetSizes, original, hnsw, faiss):
        xi = list(range(len(dataSetSizes)))
        plt.plot(xi, original, label='original')
        plt.plot(xi, hnsw, label='hnsw')
        plt.plot(xi, faiss, label='faiss')
        plt.xlabel('vectors (points) in dataset')
        plt.ylabel('time taken for NN Search')
        plt.xticks(xi, dataSetSizes)
        plt.title('performance comparison in ' + str(len(d)) + '-dimensional input domain')
        plt.legend()
        plt.show()


if __name__ == '__main__':
    simulations = 10
    xyz = TestEfficiency(simulations)
    xyz.main()
