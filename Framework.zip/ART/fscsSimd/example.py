import numpy as np
import time

# Number of features
n = 1000
# Number of training examples
m = 10000
# Initialize X and W
X = np.random.rand(n, m)
W = np.random.rand(n, 1)
# Vectorized code
t1 = time.time()
Z = np.dot(W.T, X)
print("Time taken for vectorized code is : ", (time.time() - t1) * 1000, "ms")
# Non Vectorized code
Z1 = np.zeros((1, m))
t2 = time.time()
for i in range(X.shape[1]):
    for j in range(X.shape[0]):
        Z[0][i] += W[j] * X[j][i]
print("Time taken for non vectorized code is : ", (time.time() - t2) * 1000, "ms")
